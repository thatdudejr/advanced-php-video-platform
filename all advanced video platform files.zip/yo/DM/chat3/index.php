<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="style.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif; /* Use Arial as a fallback font */
      background-color: black;
      color: white;
      line-height: 1.6;
      margin: 0; /* Remove default margin */
      padding: 0; /* Remove default padding */
    }
  </style>
  <title>PHP chat</title>
</head>
<body>
  <div class="divmain">
    <h2>Send a message!</h2>
    <form action="action.php" class="blogdesire-form" method="post">
      <input type="text" name="username" placeholder="Nickname" required autocomplete="off"> <br>
      <input type="text" name="password" placeholder="Message" required autocomplete="off"> <br>
      <input type="submit" name="submit" value="Send">
    </form>
  </div>
  
  <div class="chat-box">
    <h2>Chat:</h2>
    <pre class="chat-messages">
      <?php
      // Read and display chat messages from the file
      $chatContent = file_get_contents("chat.txt");
      echo htmlspecialchars($chatContent);
      ?>
    </pre>
  </div>

  <script>
    // Refresh chat content every 5 seconds
    setInterval(function() {
      var chatMessages = document.querySelector(".chat-messages");
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          chatMessages.textContent = this.responseText;
        }
      };
      xmlhttp.open("GET", "chat.txt", true);
      xmlhttp.send();
    }, 5000); // 5000 milliseconds = 5 seconds
  </script>
</body>
</html>
