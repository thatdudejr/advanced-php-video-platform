# Simple-PHP-chat-site
Super Simple php script that allowes you to chat to anyone who is on the site. 
It uses the php script to add to a .txt file. The txt file is displayed on the html page, as well as the form. 

View demo here: 
https://simple-php-chat.herokuapp.com/
