<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="style.css" rel="stylesheet">
  <title>Chat Rooms</title>
</head>
<body>
  <h1>Welcome to Chat Rooms</h1>
  <ul>
    <li><a href="chat1/index.php">Chat Room 1</a></li>
    <li><a href="chat2/index.php">Chat Room 2</a></li>
    <li><a href="chat3/index.php">Chat Room 3</a></li>
    <li><a href="chat4/index.php">Chat Room 4</a></li>
    <li><a href="chat5/index.php">Chat Room 5</a></li>
    <li><a href="chat6/index.php">Chat Room 6</a></li>
    <!-- Add more chat room links as needed -->
  </ul>
</body>
</html>
